'use strict';

const express    = require('express');
const path       = require('path');
const fs         = require('fs');
const initSqlJs  = require('sql.js');

const app  = express();
const PORT = 3010;
const DB_PATH = path.join(__dirname, 'reservations.db');

// ── Fichiers statiques ───────────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// ── Chargement de la base ────────────────────────────────────────────────────
let db;

async function startServer() {
  const SQL  = await initSqlJs();
  const file = fs.readFileSync(DB_PATH);
  db = new SQL.Database(file);

  console.log('✅  Base SQLite chargée depuis', DB_PATH);

  // helper : exécute un SELECT et retourne un tableau d'objets
  function query(sql, params = []) {
    const stmt    = db.prepare(sql);
    const results = [];
    stmt.bind(params);
    while (stmt.step()) {
      results.push(stmt.getAsObject());
    }
    stmt.free();
    return results;
  }

  // ── Pages HTML ─────────────────────────────────────────────────────────────
  app.get('/', (req, res) =>
    res.sendFile(path.join(__dirname, 'public', 'index.html')));

  app.get('/reservations', (req, res) =>
    res.sendFile(path.join(__dirname, 'public', 'reservations.html')));

  app.get('/listings', (req, res) =>
    res.sendFile(path.join(__dirname, 'public', 'listings.html')));

  app.get('/suivi-prises', (req, res) =>
    res.sendFile(path.join(__dirname, 'public', 'suivi-prises.html')));

  app.get('/owners', (req, res) =>
    res.sendFile(path.join(__dirname, 'public', 'owners.html')));

  // ── API : Propriétaires ────────────────────────────────────────────────────
  app.get('/api/owners', (req, res) => {
    try {
      const rows = query(`
        SELECT
          o.id,
          o.nom,
          COUNT(DISTINCT l.id) AS nb_listings,
          COUNT(DISTINCT r.id) AS nb_res
        FROM owners o
        LEFT JOIN listings l ON l.owner_id = o.id
        LEFT JOIN reservations r ON r.listing_id = l.id
        GROUP BY o.id, o.nom
        ORDER BY o.nom ASC
      `);
      res.json(rows);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: err.message });
    }
  });

  // ── API : Propriétés ───────────────────────────────────────────────────────
  app.get('/api/listings', (req, res) => {
    try {
      const rows = query(`
        SELECT
          l.id,
          l.nom,
          l.active,
          l.comm,
          l.menage,
          l.titre,
          l.owner_id,
          l.external_url,
          o.nom AS owner_nom,
          COUNT(r.id) AS nb_res
        FROM listings l
        LEFT JOIN owners o ON l.owner_id = o.id
        LEFT JOIN reservations r ON r.listing_id = l.id
        GROUP BY l.id
        ORDER BY l.nom ASC
      `);
      res.json(rows);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: err.message });
    }
  });

  // ── API : Réservations ─────────────────────────────────────────────────────
  app.get('/api/reservations', (req, res) => {
    try {
      const { plateforme, listing_id, date_from, date_to } = req.query;

      let sql = `
        SELECT
          r.id,
          r.listing_id,
          l.nom       AS listing_nom,
          o.nom       AS owner_nom,
          r.plateforme,
          r.date_debut,
          r.duree,
          r.prix_nuit,
          r.prix_total,
          r.menage,
          r.commission,
          r.hobe,
          r.versement,
          r.booking_date
        FROM reservations r
        JOIN listings l ON r.listing_id = l.id
        LEFT JOIN owners o ON l.owner_id = o.id
        WHERE 1=1
      `;
      const params = [];

      if (plateforme) { sql += ' AND r.plateforme = ?';    params.push(plateforme); }
      if (listing_id) { sql += ' AND r.listing_id = ?';    params.push(listing_id); }
      if (date_from)  { sql += ' AND r.date_debut >= ?';   params.push(date_from); }
      if (date_to)    { sql += ' AND r.date_debut <= ?';   params.push(date_to); }

      sql += ' ORDER BY r.date_debut DESC';

      const rows = query(sql, params);
      res.json(rows);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: err.message });
    }
  });

  // ── Démarrage ──────────────────────────────────────────────────────────────
  app.listen(PORT, () => {
    console.log(`🚀  Suivi Réservations  →  http://localhost:${PORT}  (v0.1.4)`);
    console.log(`    Réseau local        →  http://Black6:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('❌  Erreur au démarrage :', err);
  process.exit(1);
});
